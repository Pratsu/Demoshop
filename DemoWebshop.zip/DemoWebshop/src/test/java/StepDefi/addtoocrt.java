package StepDefi;


import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


public class addtoocrt {
    WebDriver driver;

    @Given("I am on the homepage")
    public void I_am_on_the_homepage() {
        // Setup WebDriver using WebDriverManager (handles ChromeDriver)
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demowebshop.tricentis.com/");

        }
        @When("I search for a product")
        public void i_search_for_a_product() {
        driver.findElement(By.id("small-searchterms")).sendKeys("laptop");
        driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[2]")).click();


        }
        @When("I add the first product from the search results to the cart")
        public void i_add_the_first_product_from_the_search_results_to_the_cart() {
    driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[3]/div[1]/div/div/div[1]/a/img")).click();
    driver.findElement(By.id("add-to-cart-button-31")).click();
    }
        @Then("Product should get added to the cart")
        public void Product_should_see_the_product_in_the_cart() {
        driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();

        }


    }

